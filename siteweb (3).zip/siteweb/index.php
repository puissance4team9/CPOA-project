﻿<?php 

session_start ();

include ('Model/Model.php');
include ('Model/FilmManager.php');
include ('Model/VipManager.php');

if (isset($_GET['page']))
{
	if ($_GET['page']=='details')
		{
			include 'Views/detailsVip.php';
		}
		
		if ($_GET['page']=='recherche')
		{
			include 'Views/recherche.php';
		}
		if ($_GET['page']=='recherche')
		{
			include 'Views/recherche.php';
		}
		if ($_GET['page']=='info')
		{
			include 'Views/infosfilms.php';
		}
		
		if($_GET['page']=='rechercheVip')
	{
		include 'Views/rechercheVIP.php';
	}
			if($_GET['page']=='listeVip')
	{
		include 'Views/ListeVip.php';
	}
}
else
{
			include 'Views/RechercheFilm.php';
			
}
		
require 'Views/Layout.php'; 


?>