<?php
class VipManager extends Model {
	
	public function getVip()
		{
		
			$sql = 'SELECT * from VIP';
			$req =$this->executerRequete($sql);
		
		 return $req;
		}
		
		public function getDetails($numVip){
		$sql= 'SELECT * from VIP where numVip = :choix';
		$req = $this->executerRequete($sql, array(':choix' => $numVip));
		return $req;
		
		}
		
		public function getVip1($nom, $prenom){
		
		
			$sql = 'SELECT * FROM VIP WHERE nomVip = :choix AND prenomVip = :choi';
			$req =$this->executerRequete($sql, array(':choix' => $nom, ':choi' => $prenom));	
		
		 return $req;
		}
		
		public function getRealisateur($num, $role){
		$sql= 'SELECT *
			FROM REALISATEUR, VIP
			WHERE REALISATEUR.numVip = VIP.numVip
			AND numVisa = :choix AND codeRole= :role ';
		$req = $this->executerRequete($sql, array(':choix' => $num, ':role' => $role));
		
		return $req;
		
		}
		
		public function getActeur($num, $role){
		$sql= 'SELECT *
			FROM CASTING, VIP
			WHERE CASTING.numVip = VIP.numVip
			AND codeRole= :role AND numVisa = :choix';
		$req = $this->executerRequete($sql, array(':choix' => $num, ':role' => $role));
		
		return $req;
		}
		
	
		public function getVipConjoint($num){
			
			
			$res = 'SELECT COUNT(numVip)
					FROM EVENEMENT
					WHERE numVip = :choix';
			$res = $this -> executerRequete($res, array(':choix' => $num));
			$nb= $res->fetchColumn(); 
			
			if( $nb== 0)
				
				{
					
				$sql= '	SELECT *
						FROM `VIP` 
						WHERE numVip IN( SELECT numVip
										FROM EVENEMENT
										where numVipConjoint = :choix and dateDivorce is NULL )';			
				$req = $this->executerRequete($sql, array(':choix' => $num));
					return $req;
				}
			else
				{
				
				$sql= 'SELECT *
						FROM `VIP` 
						WHERE numVip IN( SELECT numVipConjoint 
									FROM EVENEMENT
									where numVip = :choix and dateDivorce is NULL)';			
				$req = $this->executerRequete($sql, array(':choix' => $num));
				return $req;
				}
					
		}
		
		
		public function getVipDivorce($num){
			
			
			$res = 'SELECT COUNT(numVip)
					FROM EVENEMENT
					WHERE numVip = :choix';
			$res = $this -> executerRequete($res, array(':choix' => $num));
			$nb= $res->fetchColumn(); 
			
			if( $nb== 0)
				
				{
					
				$sql= '	SELECT *
						FROM `VIP` 
						WHERE numVip IN( SELECT numVip
										FROM EVENEMENT
										where numVipConjoint = :choix and dateDivorce is not NULL )';			
				$req = $this->executerRequete($sql, array(':choix' => $num));
					return $req;
				}
			else
				{
				
				$sql= 'SELECT *
						FROM `VIP` 
						WHERE numVip IN( SELECT numVipConjoint 
									FROM EVENEMENT
									where numVip = :choix and dateDivorce is not NULL)';			
				$req = $this->executerRequete($sql, array(':choix' => $num));
				return $req;
				}
					
		}
		
		public function getDate($num){
			$sql= 'SELECT *
			FROM `EVENEMENT`
			WHERE dateDivorce is NULL AND(numVip =:choix
			OR NumVipConjoint = :choix)
			LIMIT 0, 1';
			$req = $this->executerRequete($sql, array(':choix' => $num));
			return $req;
			
		}

			
		public function getDateDivorce($num){
			$sql= 'SELECT *
			FROM `EVENEMENT`
			WHERE dateDivorce is not NULL AND(numVip =:choix
			OR NumVipConjoint = :choix)
			LIMIT 1;';
			$req = $this->executerRequete($sql, array(':choix' => $num));
			return $req;
			
		}
	
		
		
		public function getVipCat($selection, $mariage)
		{
			if($selection==1)
			{
				if($mariage==1)
				{
				$sql = 'SELECT * from VIP';
				$req =$this->executerRequete($sql);
				}
				if($mariage=='Marié')
				{
				$sql = 'SELECT * from VIP where codeStatut= :mariage';
				$req = $this->executerRequete($sql, array(':mariage' => $mariage));
				}
				if($mariage=='Célibataire')
				{
				$sql = 'SELECT * from VIP where codeStatut= :mariage';
				$req = $this->executerRequete($sql, array(':mariage' => $mariage));
				}
				if($mariage=='Divorcé')
				{
				$sql = 'SELECT * from VIP where codeStatut= :mariage';
				$req = $this->executerRequete($sql, array(':mariage' => $mariage));
				}
				
			}
			else
			{
				if($mariage=='Célibataire')
				{
				$sql = 'SELECT * from VIP where civilite = :choix and codeStatut= :mariage';
				$req = $this->executerRequete($sql, array(':mariage' => $mariage, ':choix' => $selection));
				}
				if($mariage=='Marié')
				{
				$sql = 'SELECT * from VIP where civilite = :choix and codeStatut= :mariage';
				$req = $this->executerRequete($sql, array(':mariage' => $mariage, ':choix' => $selection));
				}
				if($mariage=='Divorcé')
				{
				$sql = 'SELECT * from VIP where civilite = :choix and codeStatut= :mariage';
				$req = $this->executerRequete($sql, array(':mariage' => $mariage, ':choix' => $selection));
				}
				if($mariage=='1')
				{
				$sql = 'SELECT * from VIP where civilite = :choix;';
				$req = $this->executerRequete($sql, array(':choix' => $selection));
				}				
			}

		 return $req;
		}
	}
?>