<?php
class PhotoManager extends Model {
	
	
	public function getPhoto()
		{
		
			$sql = 'SELECT * from Photo';
			$req =$this->executerRequete($sql);
		
		 return $req;
		}
	}
?>