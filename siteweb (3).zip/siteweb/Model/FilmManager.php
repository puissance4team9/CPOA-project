<?php
class FilmManager extends Model {
	
	public function getFilm($choix){
		if ($choix==1)
		{
			$sql = 'SELECT * from FILM';
			$req =$this->executerRequete($sql);
		} else
		{
			$sql = 'SELECT * FROM FILM WHERE titre like :choix OR numVisa like :choix';
			$req =$this->executerRequete($sql, array(':choix' => $choix));	
		}
		 return $req;
		}
		
		
		public function getFilmographieActeur($num){
		$sql= 'SELECT *
			FROM FILM, CASTING
			WHERE FILM.numVisa = CASTING.numVisa
			AND numVip = :choix';
		$req = $this->executerRequete($sql, array(':choix' => $num));
		
		return $req;
		
		}
		public function getFilmographieRealisateur($num){
		$sql= 'SELECT *
			FROM FILM, REALISATEUR
			WHERE FILM.numVisa = REALISATEUR.numVisa
			AND numVip = :choix';
		$req = $this->executerRequete($sql, array(':choix' => $num));
		
		return $req;
		
		}
		
	}
?>