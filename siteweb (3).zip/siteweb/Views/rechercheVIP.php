<?php

$titre = 'listeVip';
ob_start();

?>


<?php

$resultat = new VipManager();

	if(!empty($_POST['nom']) && !empty($_POST['prenom']))
	{
			
			$nom=$_POST['nom'];
					
			
			$prenom=$_POST['prenom'];
		
			
		$vip=$resultat-> getVip1($nom, $prenom);
		
		while($donnees = $vip->fetch())
{
	?> 
	<p> <div class="film">
	 <?php echo '<a href="index.php?page=details&numVip='.$donnees['numVip'].'"> <img class="image"  src="assets/images/VIP/'.$donnees['idPhoto'].'"/></a>';?> </p> 
	<span> <?php echo $donnees['prenomVip'] ;   ?>  <?php echo $donnees['nomVip'] ;   ?>  </span> </div><?php
	
} 

	} 

?> </br>
</p>




<div class="login-page">
<form method ="POST" action="index.php?page=listeVip">
				<label> Quel(s) VIP(s) ? </label>
					<select name="Categorie">
						<option value="1"  >Tous</option>
						<option value="Mme"  >Femme</option>
						<option value="M"  >Homme</option>
						</select>
					
						<INPUT type="checkbox" name='mariage' value="Marié"> Marié
						<INPUT type="checkbox" name='mariage' value="Célibataire"> Célibataire
						<INPUT type="checkbox" name='mariage' value="Divorcé"> Divorcé
				<input type ="submit" value="Mettre à jour">
</form>
</div>

</br>


 
<?php $contenu=ob_get_clean();?>