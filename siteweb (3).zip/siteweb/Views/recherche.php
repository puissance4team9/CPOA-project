﻿<?php
$titre = 'vip';
ob_start();
?>


<h2> Liste des films </h2>
<p>
<?php

$resultat = new FilmManager();
$selection=0;

	if(!empty($_POST['titre']) || !empty($_POST['numVisa']))
	{
			if(!empty($_POST['titre']))
			{
			$choix=$_POST['titre'];
			}		
			if(!empty($_POST['numVisa']))
			{
			$choix=$_POST['numVisa'];
		
			}
		$film=$resultat-> getFilm($choix);
		
	while($donnees = $film->fetch())
	{
	?> 
	<p> <div class="film">
	 <?php echo '<a href="index.php?page=info&num='.$donnees['numVisa'].'"> <img class= "image" src="assets/images/film/'.$donnees['idPhotoF'].'"/></a>';?> </p> 
	<span> <?php echo $donnees['titre'];  ?> <span> </div> <?php
	
	}  
	}
	
?>

	
<?php $contenu = ob_get_clean(); ?>



