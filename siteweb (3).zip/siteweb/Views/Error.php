﻿<?php $titre = 'Erreur !'; 
ob_start(); ?>
	<div id="Erreur">
		<p>Une erreur est survenue : <?php echo $msgErreur ?></p>
	</div>
<?php $contenu = ob_get_clean(); ?>
