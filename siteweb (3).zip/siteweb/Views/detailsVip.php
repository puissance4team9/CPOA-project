<?php
$titre = 'vip';
ob_start();


$req = new VipManager();
$num=$_GET["numVip"];
$fichier=$req -> getDetails($num);
$data=$fichier->fetch();


echo '<h2>Détails du VIP '.$num.'</h2>';?>

	
		<TABLE> 
	
	
			<TR> 
				<TD ROWSPAN=7>
				<?php 
				
					  echo '<img class="image" src="assets/images/VIP/'.$data['idPhoto'].'"/>'; 
				?>
				</TD>
				<TD> Nom : <?php echo $data['nomVip'] ; ?> </TD>
			</TR>
	
			<TR> <TD> 	Prenom : <?php echo $data['prenomVip'] ; ?></TD> </TR> 
			<TR> <TD> 	Date de naissance : <?php echo $data['dateNaissance'] ; ?></TD> </TR> 
			<TR> <TD> 	Lieu de naissance : <?php echo $data['lieuNaissance'] ; ?></TD> </TR> 
			<TR> <TD> 	Pays : <?php echo $data['nomPays'] ; ?></TD> </TR> 
			<TR> <TD> 	Statut : <?php echo $data['codeStatut'] ; ?></TD> </TR> 
			<TR> <TD> 	Métier: <?php echo $data['codeRole'] ; ?></TD> </TR> 
	</TABLE> 
	
	<div class="bloc"> <h2> Filmographie  </h2> </div>
	
	<p>

<?php

	$resultat = new FilmManager();
	$film=$resultat-> getFilmOgraphieActeur($num);	

	
	while($donnees = $film->fetch())
{
	?> 
	<p> <div class="film">
	 <?php echo '<a href="index.php?page=info&num='.$donnees['numVisa'].'"> <img src="assets/images/film/'.$donnees['idPhotoF'].'"/></a>';?> </p> 
	<span> <?php echo $donnees['titre'];  ?> </span> </div> <?php
	
}  

?> </br>
</p>
	
	<p>

<?php

	$resultat = new FilmManager();
	$film=$resultat-> getFilmOgraphieRealisateur($num);	

	
	while($donnees = $film->fetch())
{
	?> 
	<p> <div class="film">
	 <?php echo '<a href="index.php?page=info&num='.$donnees['numVisa'].'"> <img src="assets/images/film/'.$donnees['idPhotoF'].'"/></a>';?> </p> 
	<span> <?php echo $donnees['titre'];  ?> </span> </div> <?php
	
}  

?> </br>
</p>
	

<div class="bloc">
	
	<p>
	<h2> Mariage  </h2></div>

<?php

	$res = new VipManager();
	

	$marie= $res-> getVipConjoint($num);
	$date = $res -> getDate($num);

	

	
	while($donnees = $marie->fetch())
		
{
	
	?> 
	 <div class="film">
	 <?php echo '<a href="index.php?page=details&numVip='.$donnees['numVip'].'&prenom='.$donnees['prenomVip'].'"> <img src="assets/images/VIP/'.$donnees['idPhoto'].'"/> </a>';?>  
<span> <?php echo $donnees['prenomVip']; ?> <?php echo $donnees['nomVip'];  ?>   </span>   <?php
	while($donnees = $date->fetch())
		
{
	
	?> 
	
	 
<span> <?php echo $donnees['dateMariage'];  ?>   <?php echo $donnees['lieuMariage'];  ?> </span> </div> <?php
	
}  

?> <?php
	
}  

?> </br>
</p>
<div class="bloc">

	
	<p>
	<h2> Divorce  </h2></div>


<?php

	$res = new VipManager();
	

	$marie= $res-> getVipDivorce($num);
	$date = $res -> getDateDivorce($num);
	
	

	
	while($donnees = $marie ->fetch() )
		
{
	
?> 

	 <div class="film">
	
	 <?php echo '<a href="index.php?page=details&numVip='.$donnees['numVip'].'&prenom='.$donnees['prenomVip'].'"> <img src="assets/images/VIP/'.$donnees['idPhoto'].'"/> </a>';?>  
	
	<span> <?php echo $donnees['prenomVip']; ?> <?php echo $donnees['nomVip'];  ?>   </span> <?php
	
	
	while($donnees1 = $date->fetch())
		
{
	
	?> 

	
<span> <?php echo $donnees1['dateMariage'];  ?>  - <?php echo $donnees1['dateDivorce'];  ?>  <?php echo $donnees1['lieuMariage'];  ?> </span> </div>
	


<?php
}	
}  

?> </br>
</p> </div>

	
	
<?php $contenu = ob_get_clean(); ?>



