﻿<?php
$titre = 'RechercheFilm';
ob_start();
?>



<h2> Liste des films </h2>
<p>

<?php

	$resultat = new FilmManager();
	$film=$resultat-> getFilm(1);	

	
	while($donnees = $film->fetch())
{
	?> 
	<p> <div class="film">
	 <?php echo '<a href="index.php?page=info&num='.$donnees['numVisa'].'"> <img src="assets/images/film/'.$donnees['idPhotoF'].'"/></a>';?> </p> 
	<span> <?php echo $donnees['titre'];  ?> <span> </div> <?php
	
}  

?> </br>
</p>


<?php $contenu=ob_get_clean();?>
