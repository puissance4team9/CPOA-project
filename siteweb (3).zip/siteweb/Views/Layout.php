﻿<!DOCTYPE html>
    <HTML>
        <HEAD>
        <meta charset="utf-8">
		<meta name = "format-detection" content = "telephone=no" />
        <title><?php echo $titre ?></title>   <!-- Élément spécifique -->
        <link rel="stylesheet" href="assets/CSS/style.css">
		
		<!--[if lt IE 8]>
		 <div style=' clear: both; text-align:center; position: relative;'>
		   <a href="http://windows.microsoft.com/en-US/internet-explorer/products/ie/home?ocid=ie6_countdown_bannercode">
			 <img src="http://storage.ie6countdown.com/assets/100/assets/CSS/assets/CSS/assets/CSS/images/banners/warning_bar_0000_us.jpg" border="0" height="42" width="820" alt="You are using an outdated browser. For a faster, safer browsing experience, upgrade for free today." />
		   </a>
		</div>
		<![endif]-->
		<!--[if lt IE 9]>
		<script src="js/html5shiv.js"></script>
		<link rel="stylesheet" media="screen" href="css/ie.css">
		<![endif]-->
		</head>


	<body class="page1" id="top">
<!--==============================
			  header
=================================-->
	<header>
	<div class="header_top">
	<div class="container">
	  <div class="row">
		<div class="grid_12">
		  <h1><a href="#">Voicela.
		  <br> Capturing Life</a></h1>
		  paparazzi webSite de VIP's pour les fans
		</div>
	  </div>
	</div>
	</div>
	<section id="stuck_container">
<!--==============================
			  Stuck menu
 =================================-->
	<div class="container">
	  <div class="row">
		<div class="grid_12 ">
		  <h1 class="logo">
		 <li><a href="index.php">Accueil</a></li>
		  </h1>
		  <div class="navigation ">
			<nav>
			  <ul class="sf-menu">
		

				<li><a href="index.php?page=listeVip"> Fiche VIPs</a></li>
				<li>
				<form method ="POST" action="index.php?page=recherche">
				<input type="text" placeholder="Recherche Film : titre" name="titre"/> 
				<input type="text" placeholder="ou Num Film" name="numVisa"/> 
				<input type ="submit" value="Rechercher"> 
				</form> </li> <li>
				
				<form method ="POST" action="index.php?page=rechercheVip">
				<input type="text" placeholder="Prénom VIP"  name="prenom"/> 
				<input type="text" placeholder="ET Nom VIP" name="nom"/> 
				<input type ="submit" value="Rechercher">
				</form> </li>
			</ul> 
			
			</nav>
			<div class="clear"></div>
		  </div>       
		 <div class="clear"></div>  
		</div>
	 </div> 
	</div> 
	</section>
	</header>
			
		
		
					 
	 

	 <div id="contenu">

<section id="content"><div class="ic">More Website Templates @ TemplateMonster.com - August11, 2014!</div>
 <?php echo $contenu ?>
 
 
      </div>
    

</section>
	<!--==============================
	  footer
	=================================-->
	<footer id="footer">
	  <div class="container">
		<div class="row">
		  <div class="grid_12"> 
			<h2>Contacts</h2>
			<div class="footer_phone">04 72 69 20 00</div>
			<a href="#" class="footer_mail">scolarite.iut@univ-lyon1.fr</a>
			<div class="sub-copy">Website designed by TOUMI & MAISONHAUTE</div>
		  </div>
		</div>

	</div>  
	</footer>
	</BODY>
	</HTML> 