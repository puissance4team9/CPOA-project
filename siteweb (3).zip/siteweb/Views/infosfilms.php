<?php

$titre = 'infofilms';
ob_start();

?>

<?php
$req = new FilmManager();
$num=$_GET['num'];
$fichier=$req -> getFilm($num);
$data=$fichier->fetch();


echo '<h2>Détails du Film '.$num.'</h2>';?>

	
		<TABLE> 
	
	
			<TR> 
				<TD ROWSPAN=3>
				<?php 
				
					  echo '<img class="image" src="assets/images/film/'.$data['idPhotoF'].'"/>'; 
				?>
				</TD>
				<TD> Titre : <?php echo $data['titre'] ; ?> </TD>
			</TR>
	
			<TR> <TD> 	Genre : <?php echo $data['LibelleGenre'] ; ?></TD> </TR> 
			<TR> <TD> 	Annéee de sortie : <?php echo $data['annee'] ; ?></TD> </TR> 
			

	</TABLE> 
	
	
			<h2> Réalisateur </h2>
			
			<p>
			<?php 
			
			$req = new VipManager();
			$role='Realisateur';
			$realisateur=$req -> getRealisateur($num, $role);
			
										
			while($donnees = $realisateur->fetch())
			{
			?> 
			<p> <div class="film">
			<?php   echo '<a href="index.php?page=details&numVip='.$donnees['numVip'].'&prenom='.$donnees['prenomVip'].'"> <img src="assets/images/VIP/'.$donnees['idPhoto'].'"/> </a>'; ?> </p> 
			<span> 	 
			<?php echo $donnees['prenomVip'] ; ?>  <?php echo $donnees['nomVip'] ;   ?>  </span> </div> <?php
	
			}  

				?> 
			</p>
	<div class="bloc">
			<h2> Acteur </h2> </div>
			
		<p>
			<?php
			
			$req = new VipManager();
			$role='Acteur';
			$acteur=$req-> getActeur($num, $role);	
		
	while($donnees = $acteur->fetch())
{
	?> 
	<p> <div class="film">
	 <?php echo '<a href="index.php?page=details&numVip='.$donnees['numVip'].'&prenom='.$donnees['prenomVip'].'">  <img src="assets/images/VIP/'.$donnees['idPhoto'].'"/> </a>';?> </p> 
	<span> <?php echo $donnees['prenomVip'] ;   ?>  <?php echo $donnees['nomVip'] ;   ?>  </span> </div> <?php
	
}  

?> 
</p> 

	
<?php $contenu = ob_get_clean(); ?>
